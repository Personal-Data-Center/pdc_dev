from django.apps import AppConfig


class DjangoPdcLoginConfig(AppConfig):
    name = 'django_pdc_login'
