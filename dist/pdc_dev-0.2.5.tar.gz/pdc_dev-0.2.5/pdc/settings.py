PDC_SWARM_AUTHORIZATOR_API = "http://authorizator/authorizator/api/"

PDC_LOGIN_URL = "/authorizator/login"
